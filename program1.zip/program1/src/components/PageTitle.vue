<!-- src/components/PageTitle.vue -->
<template>
  <div>
    <h1>Title Page</h1>
  </div>
</template>

<script>
export default {
  name: 'PageTitle'
}
</script>
